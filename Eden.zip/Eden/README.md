# Eden of the Animals 🐾🌿

**Autor:** Dyogo Emanuel Pires Ramos  
**Linha Temática:** Entretenimento & Educação Ambiental  
**Área do Conhecimento:** Ciências da Natureza — Zoologia e Conservação  
**Tecnologias:** Python 3 & Pygame  
**Paradigma:** Programação Orientada a Objetos (POO)

---

## 📖 1. Sobre o Projeto

**Eden of the Animals** é um jogo 2D educativo e de simulação em que o jogador atua como um Guardião e Zoólogo responsável por explorar biomas selvagens, resgatar e catalogar espécies animais e construir um Zoológico sustentável organizado em recintos adequados.

Ao interagir com os animais, o jogador tem acesso a **Fichas Educativas** completas com nome científico, classe zoológica, habitat, dieta alimentar, regulação térmica, tipo de respiração e curiosidades sobre o comportamento e a conservação da espécie.

---

## 🏛️ 2. Arquitetura Orientada a Objetos (POO)

O projeto foi estruturado seguindo rigorosamente a hierarquia exigida no **Game Design Document (GDD)**:

```text
Jogo (main.py)
│
├── Animal (scripts/animais.py)
│   ├── Mamifero
│   ├── Ave
│   ├── Reptil
│   ├── Peixe
│   └── Anfibio
│
├── Jogador (scripts/jogador.py)
├── Zoologico (scripts/zoologico.py)
│   └── Recinto
├── Colecao (scripts/colecao.py)
├── Campanha das 8 Fases (scripts/fases.py)
│   ├── GerenciadorFases (Ciclo, Desbloqueios e Estrelas)
│   ├── CenaFase (Gameplay, Câmera, Terrenos e Condições)
│   ├── MenuSelecaoFases (Cards Interativos das 8 Fases)
│   ├── ModalResultadoFase (Vitória / Derrota com Dica)
│   ├── Perigos Ambientais (Espinhos, Lama, Correnteza, Água-viva, Raios, Névoa Tóxica, Fogo, Armadilhas)
│   ├── Predadores em Patrulha (Leão Territorial, Crocodilo Voraz, Javali Feroz)
│   └── Itens Coletáveis (Kits Médicos, Cantis de Água, Frutas, Antídotos, Bolhas de Ar, Extintores)
├── Interface (scripts/interfaces.py)
│   ├── TelaInicio (Menu com Campanha, Exploração Livre, Configuração e Sair)
│   ├── ModalConfiguracao (Ajustes de Áudio, Dicas, Velocidade, Reset)
│   ├── HUD (Barra Superior, Informações, Botões e Atalhos)
│   ├── FichaEducativa
│   ├── LivroColecao
│   └── NotificacaoManager
├── Cenas (scripts/cenas.py)
│   ├── CenaExploracao
│   └── CenaZoologico
└── Audio Procedural (scripts/audio.py)
```

---

## 🗺️ 3. As 8 Fases e Escala Significativa de Dificuldade

A campanha do jogo conta com **8 (oito) fases**, cada uma com aumento substancial de desafio, novos perigos ambientais, comportamento animal diferenciado, cronômetro progressivamente mais severo e mecânicas de sobrevivência:

| Fase | Título & Bioma | Dificuldade | Tempo | Animais Alvo | Perigos & Mecânicas Especiais |
|:---:|---|:---:|:---:|---|---|
| **1** | **Savana da Alvorada**<br>*(Savana Ensolarada)* | ★☆☆☆☆☆☆☆<br>Muito Fácil | 150s | Lebre, Girafa, Elefante | Tutorial e iniciação. Sem perigos letais. Aprendizado de movimentação e exame. |
| **2** | **Savana dos Felinos**<br>*(Savana Árida)* | ★★☆☆☆☆☆☆<br>Fácil-Moderada | 120s | Zebra, Guepardo, Leão | **Insolação & Patrulha:** Sol escaldante drena Hidratação (necessário sombra/cantil). Leão Alfa patrulha com círculo de visão agressivo. |
| **3** | **Floresta dos Espinheiros**<br>*(Tropical Densa)* | ★★★☆☆☆☆☆<br>Moderada | 105s | Macaco, Arara, Raposa | **Espinhos & Fuga:** Arbustos com espinhos causam dano por colisão (-22 HP). Macaco e Arara fogem em alta velocidade se você não coletar Frutas Silvestres para acalmá-los. |
| **4** | **Pântano Sombrio dos Répteis**<br>*(Zonas Úmidas)* | ★★★★☆☆☆☆<br>Média-Alta | 95s | Crocodilo, Cobra, Sapo-Cururu | **Lamaçal & Perseguição:** Lama reduz velocidade para 35%. Crocodilo Voraz dispara em perseguição rápida na água (-35 HP). Cobras no lodo e metano. |
| **5** | **O Arquipélago Oceânico**<br>*(Recife Costeiro)* | ★★★★★☆☆☆<br>Difícil | 85s | Tartaruga, Peixe-Palhaço, Pirarucu, Pinguim | **Oxigênio & Correntezas:** Fôlego diminui constantemente enquanto nada (recuperado em fontes de bolhas de ar). Correntezas marítimas fortes e águas-vivas elétricas. |
| **6** | **Santuário Noturno**<br>*(Floresta Noturna)* | ★★★★★★☆☆<br>Muito Difícil | 75s | Salamandra, Tetraz-Negro, Javali | **Escuridão & Toxinas:** Escuridão quase total com visão restrita pelo facho da lanterna. Nuvens de esporos venenosos móveis. Salamandra exige Frasco de Antídoto. |
| **7** | **O Desfiladeiro da Tempestade**<br>*(Planalto Rochoso)* | ★★★★★★★☆<br>Extrema | 68s | Cervo, Guepardo, Raposa | **Relâmpagos & Debandada:** Tempestade elétrica com círculos de aviso vermelhos que explodem raios em 1.2s (-50 HP). Ventania contínua desvia passos e debandada de feras. |
| **8** | **A Grande Calamidade Ecológica**<br>*(Reserva em Chamas)* | ★★★★★★★★<br>Máxima / Épica | 60s | Leão, Elefante, Macaco, Arara | **Incêndio Florestal & Evacuação:** Fogo em tempo real avança pelas bordas (-40 HP). Fumaça consome máscara de oxigênio. Armadilhas de caçadores. Uso de Extintores [ESPAÇO] para abrir caminho até o Heliponto de Evacuação! |

---

## 🦁 4. Espécies e Classes Zoológicas

O jogo conta com **20 espécies** distribuídas em 5 classes de vertebrados e 4 biomas:

| Classe | Espécies no Jogo | Habitat Natural |
|---|---|---|
| **Mamíferos** | Leão, Elefante, Girafa, Zebra, Guepardo, Macaco, Raposa, Cervo, Javali, Lebre | Savana e Floresta Tropical |
| **Aves** | Pinguim, Arara-Canindé, Tetraz-Negro | Áreas Polares/Costeiras e Floresta Tropical |
| **Répteis** | Crocodilo-do-Nilo, Cobra-Coral, Tartaruga-Marinha | Pântano, Floresta e Águas Costeiras |
| **Peixes** | Peixe-Palhaço, Pirarucu | Recifes de Coral e Rios Tropicais |
| **Anfíbios** | Sapo-Cururu, Salamandra-de-Fogo | Zonas Úmidas, Pântanos e Margens de Rios |

---

## 🎮 5. Controles do Jogo

| Tecla / Ação | Função |
|---|---|
| **W, A, S, D** ou **Setas** | Movimenta o personagem pelo mapa |
| **E** ou **Clique no Animal** | Resgata/Examina o animal na fase ou abre a Ficha Educativa na exploração |
| **ESPAÇO** | Utiliza Extintor de Incêndio para apagar chamas (Fase 8) |
| **Z** | Alterna entre a **Exploração** e o **Zoológico Educativo** |
| **B** | Abre/Fecha a **Enciclopédia da Fauna** (Livro de Coleção) |
| **Botão ★ 8 Fases** | Acessa o **Menu de Seleção das 8 Fases** da Campanha |
| **M** | Ativa ou silencia os efeitos sonoros (**Mudo**) |
| **ESC** | Retorna ao **Menu de Fases** / **Menu Principal** ou fecha janelas abertas |
| **Mouse (Botão Esquerdo)** | Clica em botões do menu, cards de fases, abas e itens do inventário |

---

## 🏆 6. Sistema de Progressão e Níveis

A evolução do jogador é calculada com base na quantidade de animais catalogados e fases superadas:

- **Nível 1 (0 a 5 animais):** *Explorador Novato (Início da Jornada)*
- **Nível 2 (6 a 10 animais):** *Guardião da Fauna (Avanço da Coleção)*
- **Nível 3 (11 a 19 animais):** *Mestre Zoólogo (Zoológico em Expansão)*
- **Nível 4 (20 animais):** *Éden dos Animais (Coleção 100% Completa & Campeão das 8 Fases!)*

---

## 🏞️ 7. Recintos do Zoológico

O zoológico possui 4 grandes recintos cercados com validação biológica:
1. **Recinto da Savana:** Acomoda leões, elefantes, girafas, zebras, guepardos e lebres.
2. **Recinto Tropical:** Acomoda primatas, araras, raposas, javalis, cervos e aves silvestres.
3. **Recinto Aquático:** Acomoda pinguins, peixes-palhaço, pirarucus e tartarugas.
4. **Recinto dos Répteis & Anfíbios:** Acomoda crocodilos, cobras, sapos e salamandras.

---

## 🚀 8. Como Executar

Certifique-se de possuir o **Python 3** e o **Pygame** instalados:

```bash
pip install pygame
```

Execute o jogo diretamente na raiz do projeto:

```bash
python main.py
```
