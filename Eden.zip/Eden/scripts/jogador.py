import os
import pygame

class Jogador(pygame.sprite.Sprite):
    """
    Representa o avatar do jogador (Guardião/Zoólogo).
    Permite movimentação em 8 direções pelo mapa com WASD ou setas,
    orientação visual e detecção de proximidade com animais.
    """
    def __init__(self, x, y):
        super().__init__()
        self.pos_x = float(x)
        self.pos_y = float(y)
        self.velocidade_padrao = 4.5
        self.velocidade = 4.5
        self.modificador_velocidade = 1.0
        self.olhando_direita = True
        self.direcao_atual = (0, 1)

        # Sistema de Sobrevivência e Desafios de Fase
        self.vida_max = 100
        self.vida = 100
        self.oxigenio_max = 100.0
        self.oxigenio = 100.0
        self.hidratacao_max = 100.0
        self.hidratacao = 100.0
        self.invulneravel_timer = 0
        self.inventario = {}

        self._carregar_graficos()
        self.rect = self.image.get_rect(center=(int(self.pos_x), int(self.pos_y)))
        self.anim_timer = 0
        self.frame_idx = 0

    def _carregar_graficos(self):
        caminho = os.path.join("assets", "personagem.png")
        self.frames = []
        if os.path.exists(caminho):
            try:
                img_raw = pygame.image.load(caminho).convert_alpha()
                w, h = img_raw.get_size()
                # Escala proporcionalmente para ~56x56
                escala = min(56 / w, 56 / h)
                nw, nh = int(w * escala), int(h * escala)
                base = pygame.transform.smoothscale(img_raw, (nw, nh))

                # Cria superfície centralizada
                surf1 = pygame.Surface((56, 56), pygame.SRCALPHA)
                surf1.blit(base, ((56 - nw) // 2, (56 - nh) // 2))

                # Frame 2 levemente inclinado para simular passo
                surf2 = pygame.Surface((56, 56), pygame.SRCALPHA)
                base2 = pygame.transform.smoothscale(img_raw, (nw, nh - 2))
                surf2.blit(base2, ((56 - nw) // 2, (56 - nh) // 2 + 2))

                self.frames = [surf1, surf2]
            except Exception as e:
                print(f"Aviso ao carregar personagem: {e}")

        if not self.frames:
            # Fallback elegante estilizado com chapéu de safari / zoólogo
            surf1 = pygame.Surface((56, 56), pygame.SRCALPHA)
            # Chapéu de explorador (bege/safari)
            pygame.draw.ellipse(surf1, (189, 154, 107), (10, 8, 36, 16))
            pygame.draw.ellipse(surf1, (218, 189, 140), (16, 4, 24, 14))
            # Rosto
            pygame.draw.circle(surf1, (255, 224, 189), (28, 24), 11)
            pygame.draw.circle(surf1, (40, 40, 40), (25, 23), 2)
            pygame.draw.circle(surf1, (40, 40, 40), (32, 23), 2)
            # Uniforme verde de guardião / zoólogo
            pygame.draw.rect(surf1, (46, 125, 50), (18, 35, 20, 16), border_radius=4)
            # Cinto marrom
            pygame.draw.rect(surf1, (109, 76, 65), (18, 45, 20, 4))
            self.frames = [surf1, surf1]

        self.image = self.frames[0]

    def update(self, dt, limites_mundo=None):
        keys = pygame.key.get_pressed()
        dx, dy = 0.0, 0.0

        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            dx -= 1.0
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            dx += 1.0
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            dy -= 1.0
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            dy += 1.0

        em_movimento = (dx != 0 or dy != 0)

        if em_movimento:
            # Normalização diagonal
            if dx != 0 and dy != 0:
                dx *= 0.7071
                dy *= 0.7071

            if dx < 0:
                self.olhando_direita = False
            elif dx > 0:
                self.olhando_direita = True

            self.direcao_atual = (dx, dy)
            vel_final = self.velocidade * self.modificador_velocidade
            self.pos_x += dx * vel_final
            self.pos_y += dy * vel_final

            # Animação de passos
            self.anim_timer += dt
            if self.anim_timer >= 180:
                self.anim_timer = 0
                self.frame_idx = (self.frame_idx + 1) % len(self.frames)

        else:
            self.frame_idx = 0

        # Atualiza timer de invulnerabilidade (piscada)
        if self.invulneravel_timer > 0:
            self.invulneravel_timer = max(0, self.invulneravel_timer - dt)

        # Aplica limites do mapa
        if limites_mundo:
            self.pos_x = max(limites_mundo.left + 24, min(limites_mundo.right - 24, self.pos_x))
            self.pos_y = max(limites_mundo.top + 24, min(limites_mundo.bottom - 24, self.pos_y))

        # Atualiza a orientação da imagem e efeito de invulnerabilidade
        img_base = self.frames[self.frame_idx]
        if not self.olhando_direita:
            img_render = pygame.transform.flip(img_base, True, False)
        else:
            img_render = img_base.copy()

        # Feedback visual piscante quando ferido
        if self.invulneravel_timer > 0 and (self.invulneravel_timer // 100) % 2 == 1:
            img_render.set_alpha(100)
        else:
            img_render.set_alpha(255)

        self.image = img_render
        self.rect.center = (int(self.pos_x), int(self.pos_y))

    def receber_dano(self, quantidade):
        """Aplica dano com período de graça / invulnerabilidade temporária."""
        if self.invulneravel_timer > 0 or self.vida <= 0:
            return False
        self.vida = max(0, self.vida - quantidade)
        self.invulneravel_timer = 900
        return True

    def curar(self, quantidade):
        """Restaura pontos de vida do personagem."""
        self.vida = min(self.vida_max, self.vida + quantidade)

    def adicionar_item(self, tipo_item, qtd=1):
        """Adiciona item ao inventário da expedição."""
        self.inventario[tipo_item] = self.inventario.get(tipo_item, 0) + qtd

    def consumir_item(self, tipo_item, qtd=1):
        """Consome item se houver quantidade disponível."""
        if self.inventario.get(tipo_item, 0) >= qtd:
            self.inventario[tipo_item] -= qtd
            return True
        return False

    def resetar_para_fase(self, x, y):
        """Restaura o estado do jogador ao iniciar ou reiniciar uma fase."""
        self.pos_x = float(x)
        self.pos_y = float(y)
        self.vida = self.vida_max
        self.oxigenio = self.oxigenio_max
        self.hidratacao = self.hidratacao_max
        self.invulneravel_timer = 0
        self.modificador_velocidade = 1.0
        self.inventario.clear()
        self.rect.center = (int(self.pos_x), int(self.pos_y))
