import os
import math
import random
import pygame

from scripts.animais import (
    Animal, Mamifero, Ave, Reptil, Peixe, Anfibio
)
from scripts.cenas import Camera
from scripts.interfaces import Botao

# =============================================================================
# CORES UTILIZADAS NAS FASES E INTERFACES
# =============================================================================
COR_BRANCO = (255, 255, 255)
COR_PRETO = (15, 15, 20)
COR_AMARELO = (241, 196, 15)
COR_OURO = (255, 215, 0)
COR_VERDE = (46, 204, 113)
COR_VERDE_ESCURO = (34, 112, 62)
COR_VERMELHO = (231, 76, 60)
COR_VERMELHO_ESCURO = (150, 40, 30)
COR_AZUL = (52, 152, 219)
COR_AZUL_ESCURO = (41, 128, 185)
COR_CINZA = (180, 185, 190)
COR_CINZA_ESCURO = (40, 44, 52)
COR_PAINEL = (25, 30, 42, 240)


# =============================================================================
# DADOS E METADADOS DAS 8 FASES
# =============================================================================
DADOS_DAS_OITO_FASES = [
    {
        "numero": 1,
        "titulo": "Savana da Alvorada",
        "subtitulo": "O Despertar do Zoólogo",
        "bioma": "Savana",
        "dificuldade_nivel": 1,
        "dificuldade_texto": "★☆☆☆☆☆☆☆ Muito Fácil (Iniciação / Tutorial)",
        "cor_dificuldade": (46, 204, 113),
        "tempo_limite": 150,
        "animais_alvos": ["Lebre", "Girafa", "Elefante"],
        "descricao": "Inicie sua jornada no Éden. Localize e catalogue 3 espécies dóceis da Savana aberta sem se preocupar com predadores agressivos.",
        "dica": "Aproxime-se dos animais com calma e pressione [E] quando estiver próximo para catalogá-los.",
        "perigos": [],
        "itens": ["kit_medico"],
        "clima": "dia_claro",
        "cor_chao": (218, 185, 125)
    },
    {
        "numero": 2,
        "titulo": "Savana dos Felinos",
        "subtitulo": "Calor Escaldante & Patrulha",
        "bioma": "Savana",
        "dificuldade_nivel": 2,
        "dificuldade_texto": "★★☆☆☆☆☆☆ Fácil-Moderada (Insolação & Patrulha)",
        "cor_dificuldade": (118, 215, 46),
        "tempo_limite": 120,
        "animais_alvos": ["Zebra", "Guepardo", "Leão"],
        "descricao": "O sol do meio-dia queima a savana. O Leão patrulha seu território e atacará se você invadi-lo sem cautela. Mantenha-se hidratado nas sombras de acácias ou recolha cantis!",
        "dica": "Colete cantis de água ou descanse sob a copa das árvores para não sofrer insolação. Desvie do círculo de visão do Leão!",
        "perigos": ["calor", "leao_patrulha"],
        "itens": ["cantil", "kit_medico"],
        "clima": "calor_sol",
        "cor_chao": (225, 178, 105)
    },
    {
        "numero": 3,
        "titulo": "Floresta dos Espinheiros",
        "subtitulo": "Primatas Ariscos & Vegetação Densa",
        "bioma": "Tropical",
        "dificuldade_nivel": 3,
        "dificuldade_texto": "★★★☆☆☆☆☆ Moderada (Espinhos & Fuga)",
        "cor_dificuldade": (241, 196, 15),
        "tempo_limite": 105,
        "animais_alvos": ["Macaco", "Arara", "Raposa"],
        "descricao": "A floresta está cheia de moitas com espinhos afiados. Os macacos e araras fogem em alta velocidade se você se aproximar sem carregar Frutas Silvestres para acalmá-los!",
        "dica": "Colete frutas silvestres pelo cenário antes de abordar os animais para que eles não fujam, e desvie dos arbustos pontiagudos.",
        "perigos": ["espinhos", "animais_ariscos"],
        "itens": ["fruta", "kit_medico"],
        "clima": "tropical_denso",
        "cor_chao": (46, 125, 50)
    },
    {
        "numero": 4,
        "titulo": "Pântano Sombrio dos Répteis",
        "subtitulo": "Lamaçal & Crocodilos Vorazes",
        "bioma": "Répteis",
        "dificuldade_nivel": 4,
        "dificuldade_texto": "★★★★☆☆☆☆ Média-Alta (Lamaçal & Perseguição)",
        "cor_dificuldade": (230, 126, 34),
        "tempo_limite": 95,
        "animais_alvos": ["Crocodilo", "Cobra", "Sapo-Cururu"],
        "descricao": "Lamaçal traiçoeiro reduz severamente seus passos. Crocodilos vorazes patrulham as lagoas e perseguem você em alta velocidade se pisar na água! Cobras espreitam no lodo.",
        "dica": "Evite pisar na lama funda para não ficar lento. Colete iscas de carne para distrair os crocodilos caso eles comecem a persegui-lo.",
        "perigos": ["lama", "crocodilo_voraz", "cobras_escondidas"],
        "itens": ["isca", "kit_medico"],
        "clima": "pantano_nevoa",
        "cor_chao": (55, 75, 45)
    },
    {
        "numero": 5,
        "titulo": "O Arquipélago Oceânico",
        "subtitulo": "Correntezas & Fôlego Submarino",
        "bioma": "Aquático",
        "dificuldade_nivel": 5,
        "dificuldade_texto": "★★★★★☆☆☆ Difícil (Oxigênio & Correntezas)",
        "cor_dificuldade": (231, 76, 60),
        "tempo_limite": 85,
        "animais_alvos": ["Tartaruga", "Peixe-Palhaço", "Pirarucu", "Pinguim"],
        "descricao": "Expedição marinha desafiadora! Seu fôlego diminui constantemente enquanto você nada. Correntezas marítimas fortes arrastam o guardião e águas-vivas eletrizantes flutuam no recife.",
        "dica": "Passe sobre as fontes de bolhas de ar subaquáticas para restaurar o oxigênio e use o fluxo das correntezas a seu favor.",
        "perigos": ["oxigenio_mergulho", "correntezas", "aguas_vivas"],
        "itens": ["bolha_ar", "kit_medico"],
        "clima": "aquatico_profundo",
        "cor_chao": (35, 115, 175)
    },
    {
        "numero": 6,
        "titulo": "Santuário Noturno",
        "subtitulo": "Névoa Tóxica & Escuridão Total",
        "bioma": "Noturno",
        "dificuldade_nivel": 6,
        "dificuldade_texto": "★★★★★★☆☆ Muito Difícil (Lanterna & Toxinas)",
        "cor_dificuldade": (192, 57, 43),
        "tempo_limite": 75,
        "animais_alvos": ["Salamandra", "Tetraz-Negro", "Javali"],
        "descricao": "A noite desce e a escuridão é quase impenetrável; você só enxerga através do facho da lanterna. Nuvens de esporos venenosos flutuam no escuro e as espécies exigem antídotos!",
        "dica": "Colete os Frascos de Antídoto imediatamente para neutralizar o veneno da névoa e siga o brilho bioluminescente da salamandra.",
        "perigos": ["escuridao_lanterna", "nevoa_toxica", "veneno_espore"],
        "itens": ["antidoto", "kit_medico"],
        "clima": "escuridao_noturna",
        "cor_chao": (25, 30, 38)
    },
    {
        "numero": 7,
        "titulo": "O Desfiladeiro da Tempestade",
        "subtitulo": "Raios Devastadores & Feras em Pânico",
        "bioma": "Tempestade",
        "dificuldade_nivel": 7,
        "dificuldade_texto": "★★★★★★★☆ Extrema (Relâmpagos & Debandada)",
        "cor_dificuldade": (155, 89, 182),
        "tempo_limite": 68,
        "animais_alvos": ["Cervo", "Guepardo", "Raposa"],
        "descricao": "Uma tempestade elétrica brutal atinge o vale! Relâmpagos caem do céu a cada poucos segundos com aviso sonoro e rajadas de vento empurram o jogador enquanto feras em pânico disparam.",
        "dica": "Fique atento aos círculos vermelhos no chão: quando surgirem, saia imediatamente da área antes do raio cair em 1 segundo!",
        "perigos": ["raios_eletricos", "rajadas_vento", "debandada_animais"],
        "itens": ["escudo_eletrico", "kit_medico"],
        "clima": "tempestade_raios",
        "cor_chao": (60, 60, 65)
    },
    {
        "numero": 8,
        "titulo": "A Grande Calamidade Ecológica",
        "subtitulo": "Incêndio no Éden & Evacuação Total",
        "bioma": "Incêndio",
        "dificuldade_nivel": 8,
        "dificuldade_texto": "★★★★★★★★ Máxima / Calamidade (Incêndio Florestal)",
        "cor_dificuldade": (211, 47, 47),
        "tempo_limite": 60,
        "animais_alvos": ["Leão", "Elefante", "Macaco", "Arara"],
        "descricao": "MISSÃO FINAL DE RESGATE! Um incêndio florestal se alastra pela reserva. Fogo queima em tempo real, fumaça sufocante corrói sua máscara e armadilhas de caçadores bloqueiam o caminho!",
        "dica": "Use os Extintores de Incêndio pressionando [ESPAÇO] para abrir caminhos no fogo e guie os animais até o Heliponto de Evacuação!",
        "perigos": ["fogo_propagando", "fumaca_asfixiante", "armadilhas_cacador"],
        "itens": ["extintor", "kit_medico"],
        "clima": "incendio_calamidade",
        "cor_chao": (85, 45, 30)
    }
]


# =============================================================================
# CLASSES DE PERIGOS AMBIENTAIS (POO)
# =============================================================================
class PerigoBase:
    """Classe base para perigos que ameaçam o jogador."""
    def __init__(self, x, y, largura, altura):
        self.rect = pygame.Rect(x, y, largura, altura)
        self.ativo = True

    def update(self, dt, jogador, audio=None):
        pass

    def draw(self, screen, camera):
        pass


class PerigoEspinho(PerigoBase):
    """Arbusto espinhoso pontiagudo que causa dano ao contato."""
    def __init__(self, x, y):
        super().__init__(x, y, 44, 44)
        self.dano = 22

    def update(self, dt, jogador, audio=None):
        if self.rect.colliderect(jogador.rect):
            if jogador.receber_dano(self.dano):
                if audio:
                    audio.tocar("dano")
                # Repele o jogador levemente para fora do espinho
                dx = jogador.pos_x - self.rect.centerx
                dy = jogador.pos_y - self.rect.centery
                dist = math.hypot(dx, dy) or 1.0
                jogador.pos_x += (dx / dist) * 18
                jogador.pos_y += (dy / dist) * 18

    def draw(self, screen, camera):
        r_vis = camera.aplicar_rect(self.rect)
        # Arbusto espinhoso marrom/verde com pontas afiadas
        pygame.draw.ellipse(screen, (80, 50, 30), r_vis)
        pygame.draw.ellipse(screen, (40, 70, 30), r_vis.inflate(-6, -6))
        # Espinhos afiados destacados
        cx, cy = r_vis.center
        for ang in range(0, 360, 45):
            rad = math.radians(ang)
            px = cx + math.cos(rad) * 22
            py = cy + math.sin(rad) * 22
            pygame.draw.line(screen, (220, 50, 50), (cx, cy), (px, py), 2)


class PerigoLama(PerigoBase):
    """Poça de lama que desacelera severamente o jogador."""
    def __init__(self, x, y, largura=120, altura=90):
        super().__init__(x, y, largura, altura)
        self.tempo_bolha = 0

    def update(self, dt, jogador, audio=None):
        self.tempo_bolha += dt
        if self.rect.colliderect(jogador.rect):
            jogador.modificador_velocidade = 0.35

    def draw(self, screen, camera):
        r_vis = camera.aplicar_rect(self.rect)
        pygame.draw.ellipse(screen, (60, 45, 30), r_vis)
        pygame.draw.ellipse(screen, (45, 30, 20), r_vis.inflate(-12, -10))
        # Bolhas de lodo ocasionais
        bx = r_vis.centerx + math.sin(self.tempo_bolha / 300.0) * (r_vis.width // 4)
        by = r_vis.centery + math.cos(self.tempo_bolha / 400.0) * (r_vis.height // 4)
        pygame.draw.circle(screen, (90, 70, 50), (int(bx), int(by)), 5)


class PerigoCorrenteza(PerigoBase):
    """Área marítima onde a água empurra o jogador em uma direção."""
    def __init__(self, x, y, largura, altura, empuxo_x=2.2, empuxo_y=0.0):
        super().__init__(x, y, largura, altura)
        self.empuxo_x = empuxo_x
        self.empuxo_y = empuxo_y
        self.fase_anim = 0.0

    def update(self, dt, jogador, audio=None):
        self.fase_anim += dt * 0.005
        if self.rect.colliderect(jogador.rect):
            jogador.pos_x += self.empuxo_x
            jogador.pos_y += self.empuxo_y

    def draw(self, screen, camera):
        r_vis = camera.aplicar_rect(self.rect)
        s = pygame.Surface((self.rect.width, self.rect.height), pygame.SRCALPHA)
        s.fill((41, 128, 185, 90))
        # Desenha setas de fluxo
        for ox in range(20, self.rect.width, 50):
            desl = int((self.fase_anim * 40) % 50)
            px = (ox + desl) % self.rect.width
            pygame.draw.polygon(s, (200, 240, 255, 160), [
                (px, 15), (px + 12, self.rect.height // 2), (px, self.rect.height - 15)
            ])
        screen.blit(s, r_vis.topleft)


class PerigoAguaviva(PerigoBase):
    """Água-viva que flutua verticalmente e dá choque ao toque."""
    def __init__(self, x, y, alcance_y=120):
        super().__init__(x, y, 38, 44)
        self.origem_y = y
        self.alcance_y = alcance_y
        self.vel_y = 1.2
        self.dano = 26

    def update(self, dt, jogador, audio=None):
        self.rect.y += int(self.vel_y)
        if abs(self.rect.y - self.origem_y) > self.alcance_y:
            self.vel_y *= -1

        if self.rect.colliderect(jogador.rect):
            if jogador.receber_dano(self.dano):
                if audio:
                    audio.tocar("dano")

    def draw(self, screen, camera):
        r_vis = camera.aplicar_rect(self.rect)
        cx, cy = r_vis.centerx, r_vis.top + 14
        # Cúpula translúcida rosa/violeta
        pygame.draw.circle(screen, (230, 100, 200), (cx, cy), 16)
        pygame.draw.circle(screen, (255, 180, 240), (cx, cy - 2), 10)
        # Tentáculos elétricos
        for ox in [-10, -4, 2, 8]:
            pygame.draw.line(screen, (180, 80, 220), (cx + ox, cy + 8), (cx + ox, cy + 24), 2)


class PerigoRaio:
    """Relâmpago com marcação visual prévia e queda explosiva."""
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.raio_dano = 65
        self.timer_aviso = 1200  # 1.2 segundo para escapar
        self.caiu = False
        self.concluido = False
        self.duracao_impacto = 250
        self.dano = 50

    def update(self, dt, jogador, audio=None):
        if not self.caiu:
            self.timer_aviso -= dt
            if self.timer_aviso <= 0:
                self.caiu = True
                if audio:
                    audio.tocar("raio")
                # Verifica se o jogador está na área
                dist = math.hypot(jogador.pos_x - self.x, jogador.pos_y - self.y)
                if dist <= self.raio_dano:
                    if jogador.receber_dano(self.dano):
                        if audio:
                            audio.tocar("dano")
                        # Projeta o jogador para longe
                        dx = jogador.pos_x - self.x or 1.0
                        dy = jogador.pos_y - self.y or 1.0
                        norm = math.hypot(dx, dy)
                        jogador.pos_x += (dx / norm) * 45
                        jogador.pos_y += (dy / norm) * 45
        else:
            self.duracao_impacto -= dt
            if self.duracao_impacto <= 0:
                self.concluido = True

    def draw(self, screen, camera):
        pos_vis = camera.aplicar_pos((self.x, self.y))
        if not self.caiu:
            # Círculo de aviso vermelho piscante
            pct = 1.0 - (self.timer_aviso / 1200.0)
            raio_atual = int(self.raio_dano * (0.4 + 0.6 * pct))
            cor = (255, 50, 50) if (int(self.timer_aviso / 100) % 2 == 0) else (255, 200, 0)
            pygame.draw.circle(screen, cor, pos_vis, raio_atual, 3)
            pygame.draw.circle(screen, (255, 255, 255), pos_vis, 4)
        else:
            # Clarão do raio
            pygame.draw.circle(screen, (255, 255, 255), pos_vis, self.raio_dano)
            pygame.draw.circle(screen, (100, 200, 255), pos_vis, self.raio_dano - 10)
            # Faixa vertical do céu até o chão
            pygame.draw.line(screen, (255, 255, 255), (pos_vis[0], 0), (pos_vis[0], pos_vis[1]), 8)
            pygame.draw.line(screen, (120, 220, 255), (pos_vis[0] - 3, 0), (pos_vis[0] + 3, pos_vis[1]), 4)


class PerigoNevoaToxica(PerigoBase):
    """Nuvem verde tóxica que flutua e envenena o jogador sem antídoto."""
    def __init__(self, x, y, raio=50):
        super().__init__(x - raio, y - raio, raio * 2, raio * 2)
        self.cx = float(x)
        self.cy = float(y)
        self.raio = raio
        self.vel_x = random.uniform(-0.5, 0.5)
        self.vel_y = random.uniform(-0.4, 0.4)
        self.dano_timer = 0

    def update(self, dt, jogador, audio=None):
        self.cx += self.vel_x
        self.cy += self.vel_y
        self.rect.center = (int(self.cx), int(self.cy))

        dist = math.hypot(jogador.pos_x - self.cx, jogador.pos_y - self.cy)
        if dist <= self.raio:
            self.dano_timer += dt
            if self.dano_timer >= 700:
                self.dano_timer = 0
                if jogador.receber_dano(18):
                    if audio:
                        audio.tocar("dano")

    def draw(self, screen, camera):
        pos_vis = camera.aplicar_pos((int(self.cx), int(self.cy)))
        s = pygame.Surface((self.raio * 2, self.raio * 2), pygame.SRCALPHA)
        pygame.draw.circle(s, (76, 175, 80, 110), (self.raio, self.raio), self.raio)
        pygame.draw.circle(s, (139, 195, 74, 150), (self.raio, self.raio), self.raio // 2)
        screen.blit(s, (pos_vis[0] - self.raio, pos_vis[1] - self.raio))


class PerigoFogo(PerigoBase):
    """Chama ardente que causa alto dano ao contato e pode ser apagada com extintor."""
    def __init__(self, x, y):
        super().__init__(x, y, 48, 48)
        self.tempo_anim = 0
        self.apagado = False
        self.dano = 32

    def update(self, dt, jogador, audio=None):
        if self.apagado:
            return
        self.tempo_anim += dt
        if self.rect.colliderect(jogador.rect):
            if jogador.receber_dano(self.dano):
                if audio:
                    audio.tocar("dano")

    def draw(self, screen, camera):
        if self.apagado:
            return
        r_vis = camera.aplicar_rect(self.rect)
        cx = r_vis.centerx
        cy = r_vis.bottom - 6
        osc = math.sin(self.tempo_anim / 120.0) * 4
        # Fogo animado com 3 camadas
        pontos_ext = [(cx - 20, cy), (cx + 20, cy), (cx, r_vis.top - 6 + osc)]
        pygame.draw.polygon(screen, (230, 40, 20), pontos_ext)
        pontos_med = [(cx - 13, cy), (cx + 13, cy), (cx, r_vis.top + 6 + osc)]
        pygame.draw.polygon(screen, (255, 140, 0), pontos_med)
        pontos_int = [(cx - 7, cy), (cx + 7, cy), (cx, r_vis.top + 16 + osc)]
        pygame.draw.polygon(screen, (255, 230, 80), pontos_int)


class PerigoArmadilha(PerigoBase):
    """Armadilha oculta de caçadores que prende e fere o jogador."""
    def __init__(self, x, y):
        super().__init__(x, y, 36, 36)
        self.armada = True
        self.timer_preso = 0

    def update(self, dt, jogador, audio=None):
        if self.armada and self.rect.colliderect(jogador.rect):
            self.armada = False
            self.timer_preso = 2000
            if jogador.receber_dano(25):
                if audio:
                    audio.tocar("dano")

        if self.timer_preso > 0:
            self.timer_preso -= dt
            jogador.modificador_velocidade = 0.0

    def draw(self, screen, camera):
        r_vis = camera.aplicar_rect(self.rect)
        if self.armada:
            # Quase invisível nas cinzas/chão
            pygame.draw.circle(screen, (90, 80, 75), r_vis.center, 12, 2)
            pygame.draw.line(screen, (160, 60, 60), r_vis.topleft, r_vis.bottomright, 2)
        else:
            # Disparada / fechada
            pygame.draw.circle(screen, (160, 40, 40), r_vis.center, 16)
            pygame.draw.circle(screen, (220, 220, 220), r_vis.center, 8, 2)


class PredadorPatrulha:
    """Predador móvel agressivo com sprite visual de animal e perseguição."""
    def __init__(self, nome, x, y, raio_patrulha=180, velocidade=2.4, dano=30):
        self.nome = nome
        self.origem_x = x
        self.origem_y = y
        self.pos_x = float(x)
        self.pos_y = float(y)
        self.raio_patrulha = raio_patrulha
        self.velocidade = velocidade
        self.dano = dano
        self.em_alerta = False
        self.tempo_mudanca = 0
        self.dir_x = 1.0
        self.dir_y = 0.0
        self.distracao_timer = 0
        self.rect = pygame.Rect(x - 26, y - 26, 52, 52)

        # Carrega o sprite visual do predador
        self.image = self._carregar_sprite_predador(nome)

    def _carregar_sprite_predador(self, nome):
        mapa_arquivo = {
            "Leão Alfa": "leao.png",
            "Crocodilo Voraz": "crocodilo.png",
            "Cobra Peçonhenta": "cobra.png",
            "Javali Feroz": "javali.png"
        }
        arquivo = mapa_arquivo.get(nome)
        if arquivo:
            caminho = os.path.join("assets", arquivo)
            if os.path.exists(caminho):
                try:
                    img_raw = pygame.image.load(caminho)
                    canto = img_raw.get_at((0, 0))
                    if canto[3] == 255 and canto[0] > 180:
                        img_temp = img_raw.convert()
                        img_temp.set_colorkey(canto[:3])
                        img = pygame.Surface(img_raw.get_size(), pygame.SRCALPHA)
                        img.blit(img_temp, (0, 0))
                    else:
                        img = img_raw.convert_alpha()
                    w, h = img.get_size()
                    escala = min(52 / w, 52 / h)
                    nw, nh = max(16, int(w * escala)), max(16, int(h * escala))
                    scaled = pygame.transform.smoothscale(img, (nw, nh))
                    surf = pygame.Surface((52, 52), pygame.SRCALPHA)
                    surf.blit(scaled, ((52 - nw) // 2, (52 - nh) // 2))
                    return surf
                except Exception as e:
                    print(f"Aviso predador {arquivo}: {e}")

        surf = pygame.Surface((52, 52), pygame.SRCALPHA)
        pygame.draw.ellipse(surf, (180, 70, 30), (4, 10, 44, 32))
        return surf

    def update(self, dt, jogador, audio=None):
        self.rect.center = (int(self.pos_x), int(self.pos_y))

        # Se estiver distraído por isca jogada pelo jogador
        if self.distracao_timer > 0:
            self.distracao_timer -= dt
            self.em_alerta = False
            return

        dist_jogador = math.hypot(jogador.pos_x - self.pos_x, jogador.pos_y - self.pos_y)

        # Raio de detecção
        if dist_jogador <= self.raio_patrulha:
            self.em_alerta = True
            # Persegue ativamente o jogador
            dx = jogador.pos_x - self.pos_x
            dy = jogador.pos_y - self.pos_y
            norm = math.hypot(dx, dy) or 1.0
            self.dir_x = dx / norm
            self.dir_y = dy / norm
            self.pos_x += self.dir_x * (self.velocidade * 1.3)
            self.pos_y += self.dir_y * (self.velocidade * 1.3)

            # Mordida ao encostar
            if self.rect.colliderect(jogador.rect):
                if jogador.receber_dano(self.dano):
                    if audio:
                        audio.tocar("dano")
        else:
            self.em_alerta = False
            # Patrulha calma ao redor da origem
            self.tempo_mudanca -= dt
            if self.tempo_mudanca <= 0:
                self.tempo_mudanca = random.randint(1500, 3500)
                ang = random.uniform(0, 2 * math.pi)
                self.dir_x = math.cos(ang)
                self.dir_y = math.sin(ang)

            self.pos_x += self.dir_x * self.velocidade
            self.pos_y += self.dir_y * self.velocidade

            # Mantém dentro do raio de patrulha
            dist_origem = math.hypot(self.pos_x - self.origem_x, self.pos_y - self.origem_y)
            if dist_origem > self.raio_patrulha:
                dx = self.origem_x - self.pos_x
                dy = self.origem_y - self.pos_y
                norm = math.hypot(dx, dy) or 1.0
                self.dir_x = dx / norm
                self.dir_y = dy / norm

    def draw(self, screen, camera):
        r_vis = camera.aplicar_rect(self.rect)

        # Renderiza o sprite do predador virado na direção correta
        if self.dir_x < 0:
            img_render = pygame.transform.flip(self.image, True, False)
        else:
            img_render = self.image

        screen.blit(img_render, r_vis.topleft)

        # Círculo visual de perigo se estiver em alerta
        if self.em_alerta:
            pygame.draw.circle(screen, (255, 50, 50), r_vis.center, self.raio_patrulha, 1)
            # Sinal de exclamação e aura vermelha sobre o predador
            pygame.draw.rect(screen, (255, 30, 30), (r_vis.centerx - 2, r_vis.top - 18, 4, 10))
            pygame.draw.circle(screen, (255, 30, 30), (r_vis.centerx, r_vis.top - 4), 2)


# =============================================================================
# ITENS COLETÁVEIS NO CENÁRIO
# =============================================================================
class ItemColetavel:
    """Itens espalhados na fase para ajudar o jogador a superar as dificuldades."""
    def __init__(self, tipo, x, y):
        self.tipo = tipo  # "cantil", "fruta", "antidoto", "bolha_ar", "extintor", "kit_medico", "isca"
        self.x = float(x)
        self.y = float(y)
        self.rect = pygame.Rect(x - 16, y - 16, 32, 32)
        self.tempo_anim = random.random() * 1000
        self.coletado = False

    def update(self, dt, jogador, audio=None):
        if self.coletado:
            return
        self.tempo_anim += dt
        if self.rect.colliderect(jogador.rect):
            self.coletado = True
            if audio:
                audio.tocar("coleta")

            # Efeitos imediatos
            if self.tipo == "kit_medico":
                jogador.curar(35)
            elif self.tipo == "cantil":
                jogador.hidratacao = min(jogador.hidratacao_max, jogador.hidratacao + 45)
            elif self.tipo == "bolha_ar":
                jogador.oxigenio = min(jogador.oxigenio_max, jogador.oxigenio + 50)
            elif self.tipo == "extintor":
                jogador.adicionar_item("extintor", 2)
            elif self.tipo == "fruta":
                jogador.adicionar_item("fruta", 1)
            elif self.tipo == "antidoto":
                jogador.adicionar_item("antidoto", 1)
            elif self.tipo == "isca":
                jogador.adicionar_item("isca", 1)

    def draw(self, screen, camera):
        if self.coletado:
            return
        r_vis = camera.aplicar_rect(self.rect)
        offset_y = int(math.sin(self.tempo_anim / 250.0) * 4)
        cx = r_vis.centerx
        cy = r_vis.centery + offset_y

        # Brilho circular suave
        pygame.draw.circle(screen, (255, 255, 255, 120), (cx, cy), 18)

        if self.tipo == "kit_medico":
            pygame.draw.rect(screen, (255, 255, 255), (cx - 10, cy - 10, 20, 20), border_radius=4)
            pygame.draw.rect(screen, (231, 76, 60), (cx - 2, cy - 8, 4, 16))
            pygame.draw.rect(screen, (231, 76, 60), (cx - 8, cy - 2, 16, 4))
        elif self.tipo == "cantil":
            pygame.draw.circle(screen, (52, 152, 219), (cx, cy + 2), 11)
            pygame.draw.rect(screen, (180, 190, 205), (cx - 4, cy - 10, 8, 6))
        elif self.tipo == "fruta":
            pygame.draw.circle(screen, (230, 80, 50), (cx, cy), 10)
            pygame.draw.line(screen, (46, 204, 113), (cx, cy - 10), (cx + 4, cy - 16), 2)
        elif self.tipo == "antidoto":
            pygame.draw.rect(screen, (46, 204, 113), (cx - 7, cy - 8, 14, 18), border_radius=3)
            pygame.draw.rect(screen, (240, 240, 240), (cx - 4, cy - 13, 8, 5))
        elif self.tipo == "bolha_ar":
            pygame.draw.circle(screen, (130, 220, 255), (cx, cy), 12, 3)
            pygame.draw.circle(screen, (255, 255, 255), (cx - 3, cy - 3), 3)
        elif self.tipo == "extintor":
            pygame.draw.rect(screen, (211, 47, 47), (cx - 6, cy - 8, 12, 20), border_radius=3)
            pygame.draw.line(screen, (50, 50, 50), (cx + 2, cy - 12), (cx + 10, cy - 4), 2)
        else:
            pygame.draw.circle(screen, (241, 196, 15), (cx, cy), 10)


# =============================================================================
# CENA DE EXECUÇÃO DE UMA FASE (GAMEPLAY DA FASE)
# =============================================================================
class CenaFase:
    """
    Controla o ciclo de jogo dentro de uma fase específica (Fase 1 a 8).
    Executa mapa, câmera, perigos, clima, objetivos, itens e condições de vitória/derrota.
    """
    def __init__(self, largura_tela, altura_tela, config_fase, todos_animais, jogador, audio):
        self.largura_tela = largura_tela
        self.altura_tela = altura_tela
        self.config = config_fase
        self.audio = audio
        self.jogador = jogador

        self.largura_mundo = 1600
        self.altura_mundo = 1200
        self.rect_mundo = pygame.Rect(0, 0, self.largura_mundo, self.altura_mundo)
        self.camera = Camera(largura_tela, altura_tela, self.largura_mundo, self.altura_mundo)

        # Reinicia o jogador na posição inicial da fase
        self.jogador.resetar_para_fase(200, 200)

        # Filtra os animais que participam como alvos desta fase
        self.animais_fase = []
        for nome in self.config["animais_alvos"]:
            for a in todos_animais:
                if a.nome == nome and a not in self.animais_fase:
                    # Posiciona os animais distribuídos pelo cenário da fase
                    a.pos_x = float(random.randint(450, self.largura_mundo - 200))
                    a.pos_y = float(random.randint(250, self.altura_mundo - 200))
                    a.origem_x = a.pos_x
                    a.origem_y = a.pos_y
                    a.rect.center = (int(a.pos_x), int(a.pos_y))
                    self.animais_fase.append(a)
                    break

        self.animais_resgatados = []

        # Cronômetro da Fase
        self.tempo_restante = float(self.config["tempo_limite"])
        self.tempo_total_fase = float(self.config["tempo_limite"])
        self.tempo_decorrido = 0.0

        # Zona de Evacuação / Conclusão
        self.rect_evacuacao = pygame.Rect(self.largura_mundo - 240, self.altura_mundo - 240, 200, 200)

        # Perigos e Itens
        self.perigos = []
        self.predadores = []
        self.raios = []
        self.timer_proximo_raio = random.randint(2500, 4000)
        self.itens = []
        self.vento_x = 0.0
        self.vento_y = 0.0
        self.vento_timer = 0

        self._gerar_cenario_e_perigos()

        # Superfície do terreno da fase pré-construída
        self.surf_mapa = pygame.Surface((self.largura_mundo, self.altura_mundo))
        self._construir_terreno()

        # Estado da fase: "jogando", "vitoria", "derrota"
        self.status = "jogando"
        self.motivo_derrota = ""
        self.estrelas_obtidas = 0

    def _gerar_cenario_e_perigos(self):
        """Instancia os perigos e itens de acordo com a configuração da fase."""
        num = self.config["numero"]

        # 1. Itens no cenário
        tipos_itens = self.config.get("itens", ["kit_medico"])
        for _ in range(7):
            tipo = random.choice(tipos_itens)
            ix = random.randint(250, self.largura_mundo - 250)
            iy = random.randint(200, self.altura_mundo - 250)
            self.itens.append(ItemColetavel(tipo, ix, iy))

        # Sempre adiciona 2 kits médicos extras em fases difíceis
        if num >= 4:
            for _ in range(2):
                ix = random.randint(300, self.largura_mundo - 300)
                iy = random.randint(300, self.altura_mundo - 300)
                self.itens.append(ItemColetavel("kit_medico", ix, iy))

        # 2. Perigos específicos por fase
        if num == 2:  # Leão territorial em patrulha
            self.predadores.append(PredadorPatrulha("Leão Alfa", 800, 600, raio_patrulha=210, velocidade=2.6, dano=32))

        elif num == 3:  # Arbustos espinhosos
            for _ in range(14):
                ex = random.randint(250, self.largura_mundo - 200)
                ey = random.randint(200, self.altura_mundo - 200)
                self.perigos.append(PerigoEspinho(ex, ey))

        elif num == 4:  # Pântano com lama e crocodilos
            for lx, ly in [(400, 300), (900, 400), (600, 800), (1200, 750)]:
                self.perigos.append(PerigoLama(lx, ly, 180, 130))
            self.predadores.append(PredadorPatrulha("Crocodilo Voraz", 700, 500, raio_patrulha=220, velocidade=2.7, dano=35))
            self.predadores.append(PredadorPatrulha("Cobra Peçonhenta", 1100, 800, raio_patrulha=160, velocidade=2.2, dano=24))

        elif num == 5:  # Aquático: correntezas e águas-vivas
            self.perigos.append(PerigoCorrenteza(350, 400, 300, 100, empuxo_x=2.4, empuxo_y=0.0))
            self.perigos.append(PerigoCorrenteza(850, 700, 120, 350, empuxo_x=0.0, empuxo_y=2.5))
            for ay in [300, 500, 700, 900]:
                self.perigos.append(PerigoAguaviva(600, ay, alcance_y=100))
                self.perigos.append(PerigoAguaviva(1100, ay, alcance_y=120))

        elif num == 6:  # Noturno: névoas tóxicas flutuantes
            for _ in range(6):
                nx = random.randint(300, self.largura_mundo - 300)
                ny = random.randint(300, self.altura_mundo - 300)
                self.perigos.append(PerigoNevoaToxica(nx, ny, raio=55))

        elif num == 7:  # Tempestade: ventos e raios frequentes
            self.predadores.append(PredadorPatrulha("Javali Feroz", 650, 650, raio_patrulha=230, velocidade=3.2, dano=30))

        elif num == 8:  # Incêndio e armadilhas
            # Fogo nas bordas e espalhado
            for fx in range(100, self.largura_mundo - 100, 160):
                self.perigos.append(PerigoFogo(fx, 120))
                self.perigos.append(PerigoFogo(fx, self.altura_mundo - 140))
            for fy in range(250, self.altura_mundo - 250, 150):
                self.perigos.append(PerigoFogo(120, fy))
                self.perigos.append(PerigoFogo(self.largura_mundo - 140, fy))
            # Focos de fogo internos
            for _ in range(12):
                fx = random.randint(300, self.largura_mundo - 300)
                fy = random.randint(300, self.altura_mundo - 300)
                self.perigos.append(PerigoFogo(fx, fy))
            # Armadilhas de caçador
            for _ in range(8):
                ax = random.randint(300, self.largura_mundo - 300)
                ay = random.randint(300, self.altura_mundo - 300)
                self.perigos.append(PerigoArmadilha(ax, ay))

    def _construir_terreno(self):
        cor_chao = self.config["cor_chao"]
        self.surf_mapa.fill(cor_chao)

        bioma = self.config.get("bioma", "")
        num = self.config["numero"]

        # Carrega e escala os cenários ilustrados em alta resolução
        mapa_cenarios = {
            "Tropical": "tropical.png",
            "Répteis": "repteis.png",
            "Aquático": "aquatico.png",
            "Noturno": "repteis.png",
            "Incêndio": "tropical.png"
        }

        arquivo_bg = mapa_cenarios.get(bioma)
        if arquivo_bg:
            caminho_bg = os.path.join("assets", arquivo_bg)
            if os.path.exists(caminho_bg):
                try:
                    raw_bg = pygame.image.load(caminho_bg).convert()
                    scaled_bg = pygame.transform.smoothscale(raw_bg, (self.largura_mundo, self.altura_mundo))
                    self.surf_mapa.blit(scaled_bg, (0, 0))

                    # Filtro noturno escuro para a Fase 6
                    if bioma == "Noturno":
                        filtro_noturno = pygame.Surface((self.largura_mundo, self.altura_mundo), pygame.SRCALPHA)
                        filtro_noturno.fill((10, 15, 28, 165))
                        self.surf_mapa.blit(filtro_noturno, (0, 0))

                    # Filtro de terra arrasada e brasa para a Fase 8
                    elif bioma == "Incêndio":
                        filtro_fogo = pygame.Surface((self.largura_mundo, self.altura_mundo), pygame.SRCALPHA)
                        filtro_fogo.fill((110, 30, 12, 160))
                        self.surf_mapa.blit(filtro_fogo, (0, 0))
                except Exception as e:
                    print(f"Aviso ao carregar cenário {arquivo_bg}: {e}")

        # Detalhes específicos de relevo para Savana e Tempestade
        if num in [1, 2]:
            for ox in range(120, self.largura_mundo, 220):
                for oy in range(100, self.altura_mundo, 200):
                    pygame.draw.circle(self.surf_mapa, (165, 135, 75), (ox, oy), 26)
                    pygame.draw.circle(self.surf_mapa, (140, 110, 50), (ox, oy), 20)
        elif num == 7:
            for ox in range(90, self.largura_mundo, 170):
                for oy in range(80, self.altura_mundo, 160):
                    pygame.draw.ellipse(self.surf_mapa, (42, 42, 48), (ox, oy, 74, 42))
                    pygame.draw.ellipse(self.surf_mapa, (32, 32, 38), (ox + 10, oy + 5, 54, 30))

        # Moldura das bordas do mapa
        pygame.draw.rect(self.surf_mapa, (20, 20, 25), self.rect_mundo, 16)

        # Zona de Evacuação / Conclusão
        pygame.draw.rect(self.surf_mapa, (46, 204, 113, 160), self.rect_evacuacao, border_radius=12)
        pygame.draw.rect(self.surf_mapa, (241, 196, 15), self.rect_evacuacao, 4, border_radius=12)

    def apagar_fogo_proximo(self):
        """Permite que o jogador use extintor para abrir caminho entre o fogo."""
        if self.jogador.consumir_item("extintor", 1):
            if self.audio:
                self.audio.tocar("extintor")
            for perigo in self.perigos:
                if isinstance(perigo, PerigoFogo) and not perigo.apagado:
                    dist = math.hypot(self.jogador.pos_x - perigo.rect.centerx, self.jogador.pos_y - perigo.rect.centery)
                    if dist <= 110:
                        perigo.apagado = True
            return True
        return False

    def update(self, dt):
        if self.status != "jogando":
            return

        self.tempo_decorrido += dt
        self.tempo_restante -= (dt / 1000.0)

        # 1. Checagem de Tempo Esgotado
        if self.tempo_restante <= 0:
            self.tempo_restante = 0
            self.status = "derrota"
            self.motivo_derrota = "O tempo limite da expedição se esgotou antes que o resgate fosse concluído!"
            if self.audio:
                self.audio.tocar("derrota")
            return

        # 2. Atualização do Jogador
        self.jogador.modificador_velocidade = 1.0
        self.jogador.update(dt, limites_mundo=self.rect_mundo)
        self.camera.seguir(self.jogador.pos_x, self.jogador.pos_y)

        # 3. Mecânicas Ambientais Especiais da Fase
        num = self.config["numero"]

        # Fase 2: Insolação / Hidratação
        if num == 2:
            self.jogador.hidratacao = max(0.0, self.jogador.hidratacao - (dt / 1000.0) * 2.8)
            if self.jogador.hidratacao <= 0:
                if self.jogador.receber_dano(8):
                    if self.audio:
                        self.audio.tocar("dano")

        # Fase 5: Fôlego e Oxigênio Subaquático
        if num == 5:
            self.jogador.oxigenio = max(0.0, self.jogador.oxigenio - (dt / 1000.0) * 3.5)
            if self.jogador.oxigenio <= 0:
                if self.jogador.receber_dano(14):
                    if self.audio:
                        self.audio.tocar("dano")

        # Fase 7: Ventania da Tempestade e Relâmpagos periódicos
        if num == 7:
            self.vento_timer -= dt
            if self.vento_timer <= 0:
                self.vento_timer = random.randint(2000, 4500)
                self.vento_x = random.uniform(-1.8, 1.8)
                self.vento_y = random.uniform(-1.2, 1.2)
            self.jogador.pos_x += self.vento_x
            self.jogador.pos_y += self.vento_y

            self.timer_proximo_raio -= dt
            if self.timer_proximo_raio <= 0:
                self.timer_proximo_raio = random.randint(2200, 3600)
                # Raio cai perto do jogador para exigir reação ágil!
                rx = self.jogador.pos_x + random.randint(-140, 140)
                ry = self.jogador.pos_y + random.randint(-140, 140)
                rx = max(60, min(self.largura_mundo - 60, rx))
                ry = max(60, min(self.altura_mundo - 60, ry))
                self.raios.append(PerigoRaio(rx, ry))

        # Fase 8: Fumaça da Calamidade
        if num == 8:
            self.jogador.oxigenio = max(0.0, self.jogador.oxigenio - (dt / 1000.0) * 3.2)
            if self.jogador.oxigenio <= 0:
                if self.jogador.receber_dano(12):
                    if self.audio:
                        self.audio.tocar("dano")

        # 4. Atualização dos Raios
        for raio in list(self.raios):
            raio.update(dt, self.jogador, self.audio)
            if raio.concluido:
                self.raios.remove(raio)

        # 5. Atualização de Perigos Estáticos e Predadores
        for perigo in self.perigos:
            perigo.update(dt, self.jogador, self.audio)

        for pred in self.predadores:
            pred.update(dt, self.jogador, self.audio)

        # 6. Atualização de Itens
        for item in self.itens:
            item.update(dt, self.jogador, self.audio)

        # 7. Atualização dos Animais da Fase
        for animal in self.animais_fase:
            if animal not in self.animais_resgatados:
                # Na fase 3, animais ariscos fogem se o jogador se aproximar sem fruta
                if num == 3 and animal.nome in ["Macaco", "Arara"]:
                    dist_p = math.hypot(animal.pos_x - self.jogador.pos_x, animal.pos_y - self.jogador.pos_y)
                    if dist_p < 140 and self.jogador.inventario.get("fruta", 0) == 0:
                        dx = animal.pos_x - self.jogador.pos_x or 1.0
                        dy = animal.pos_y - self.jogador.pos_y or 1.0
                        norm = math.hypot(dx, dy)
                        animal.pos_x += (dx / norm) * 2.8
                        animal.pos_y += (dy / norm) * 2.8
                        animal.rect.center = (int(animal.pos_x), int(animal.pos_y))
                animal.update(dt, limites_area=self.rect_mundo)

        # 8. Checagem de Morte do Jogador
        if self.jogador.vida <= 0:
            self.status = "derrota"
            self.motivo_derrota = "O Guardião sucumbiu aos perigos severos deste bioma!"
            if self.audio:
                self.audio.tocar("derrota")
            return

        # 9. Checagem de Condição de Vitória
        todos_resgatados = len(self.animais_resgatados) == len(self.animais_fase)
        if todos_resgatados:
            # Em todas as fases, o jogador deve se dirigir até a Zona de Evacuação/Resgate
            if self.rect_evacuacao.colliderect(self.jogador.rect):
                self.status = "vitoria"
                self._calcular_estrelas()
                if self.audio:
                    self.audio.tocar("vitoria_fase")

    def interagir_com_animal(self, animal):
        """Resgata e cataloga o animal na fase ao apertar [E]."""
        if animal in self.animais_fase and animal not in self.animais_resgatados:
            # Verifica requisitos da fase se houver
            num = self.config["numero"]
            if num == 3 and animal.nome in ["Macaco", "Arara"]:
                if not self.jogador.consumir_item("fruta", 1):
                    return False, f"O {animal.nome} está arisco! Colete uma Fruta Silvestre para acalmá-lo."

            if num == 6 and animal.nome in ["Salamandra"]:
                if not self.jogador.consumir_item("antidoto", 1):
                    return False, f"A {animal.nome} emana toxinas na pele! Colete um Antídoto antes de tocá-la."

            self.animais_resgatados.append(animal)
            animal.descoberto = True
            if self.audio:
                self.audio.tocar("descoberta")
            return True, f"🎉 {animal.nome} resgatado e catalogado com sucesso!"

        return False, ""

    def _calcular_estrelas(self):
        """Calcula de 1 a 3 estrelas conforme a performance do jogador."""
        # 1 estrela garantida por concluir a fase
        estrelas = 1
        # 2 estrelas se tiver terminado com vida alta (> 45 HP)
        if self.jogador.vida >= 45:
            estrelas += 1
        # 3 estrelas se tiver sobrado tempo (> 20% do tempo total)
        if self.tempo_restante >= (self.tempo_total_fase * 0.2):
            estrelas += 1
        self.estrelas_obtidas = min(3, estrelas)

    def draw(self, screen, fontes):
        # 1. Terreno visível através da câmera
        sub_mapa = self.surf_mapa.subsurface((self.camera.offset_x, self.camera.offset_y, self.largura_tela, self.altura_tela))
        screen.blit(sub_mapa, (0, 0))

        # 2. Zona de Evacuação
        r_evac = self.camera.aplicar_rect(self.rect_evacuacao)
        if r_evac.colliderect(pygame.Rect(0, 0, self.largura_tela, self.altura_tela)):
            pygame.draw.rect(screen, (46, 204, 113), r_evac, border_radius=10)
            pygame.draw.rect(screen, (241, 196, 15), r_evac, 3, border_radius=10)
            txt_ev = fontes["pequena"].render("🚁 ZONA DE RESGATE", True, (255, 255, 255))
            screen.blit(txt_ev, txt_ev.get_rect(center=r_evac.center))

        # 3. Perigos Estáticos
        for perigo in self.perigos:
            perigo.draw(screen, self.camera)

        # 4. Predadores
        for pred in self.predadores:
            pred.draw(screen, self.camera)

        # 5. Itens Coletáveis
        for item in self.itens:
            item.draw(screen, self.camera)

        # 6. Animais da Fase
        animal_mais_proximo = None
        for animal in self.animais_fase:
            rect_vis = self.camera.aplicar_rect(animal.rect)
            if rect_vis.colliderect(pygame.Rect(0, 0, self.largura_tela, self.altura_tela)):
                screen.blit(animal.image, rect_vis)
                if animal in self.animais_resgatados:
                    # Selo de resgatado
                    pygame.draw.circle(screen, (46, 204, 113), (rect_vis.right - 4, rect_vis.top + 4), 8)
                    txt_ok = fontes["pequena"].render("✓", True, (255, 255, 255))
                    screen.blit(txt_ok, (rect_vis.right - 9, rect_vis.top - 2))
                else:
                    dist = math.hypot(self.jogador.pos_x - animal.pos_x, self.jogador.pos_y - animal.pos_y)
                    if dist <= 80:
                        animal_mais_proximo = (animal, rect_vis)

        # 7. Raios da Fase
        for raio in self.raios:
            raio.draw(screen, self.camera)

        # 8. Jogador
        rect_jog = self.camera.aplicar_rect(self.jogador.rect)
        screen.blit(self.jogador.image, rect_jog)

        # Dica visual se estiver próximo a um animal
        if animal_mais_proximo:
            anim, r_v = animal_mais_proximo
            pygame.draw.rect(screen, COR_AMARELO, r_v.inflate(10, 10), 2, border_radius=6)
            txt_dica = fontes["pequena"].render(f"[E] Resgatar {anim.nome}", True, (255, 255, 255))
            r_d = txt_dica.get_rect(center=(r_v.centerx, r_v.top - 16))
            fundo_d = r_d.inflate(12, 6)
            pygame.draw.rect(screen, (20, 25, 35, 220), fundo_d, border_radius=4)
            pygame.draw.rect(screen, COR_AMARELO, fundo_d, 1, border_radius=4)
            screen.blit(txt_dica, r_d)

        # 9. Efeitos Climáticos e de Iluminação
        self._desenhar_efeito_clima(screen)

        # 10. HUD Superior da Fase
        self._desenhar_hud_fase(screen, fontes)

        return animal_mais_proximo[0] if animal_mais_proximo else None

    def _desenhar_efeito_clima(self, screen):
        """Renderiza iluminação, névoa, escuridão com lanterna e chuva."""
        clima = self.config.get("clima", "dia_claro")

        if clima == "escuridao_noturna":
            # Escuridão quase total com máscara de lanterna circular centrada no jogador
            mascara = pygame.Surface((self.largura_tela, self.altura_tela), pygame.SRCALPHA)
            mascara.fill((10, 12, 18, 245))  # Escuridão densa

            pos_jog_tela = self.camera.aplicar_pos((int(self.jogador.pos_x), int(self.jogador.pos_y)))
            # Círculo de visão iluminado pela lanterna
            pygame.draw.circle(mascara, (0, 0, 0, 0), pos_jog_tela, 140)
            pygame.draw.circle(mascara, (255, 240, 180, 40), pos_jog_tela, 160)
            screen.blit(mascara, (0, 0))

        elif clima == "incendio_calamidade":
            # Filtro avermelhado/alaranjado com brasas
            velo = pygame.Surface((self.largura_tela, self.altura_tela), pygame.SRCALPHA)
            velo.fill((180, 40, 10, 50))
            screen.blit(velo, (0, 0))

        elif clima == "tempestade_raios":
            # Chuva diagonal torrencial
            for _ in range(35):
                rx = random.randint(0, self.largura_tela)
                ry = random.randint(0, self.altura_tela)
                pygame.draw.line(screen, (180, 210, 240, 160), (rx, ry), (rx - 10, ry + 16), 1)

    def _desenhar_hud_fase(self, screen, fontes):
        """Renderiza barra de vida, cronômetro, objetivos e inventário."""
        fonte_p = fontes["pequena"]
        fonte_m = fontes["media"]

        # Faixa superior translúcida
        faixa = pygame.Surface((self.largura_tela, 54), pygame.SRCALPHA)
        faixa.fill((20, 25, 35, 230))
        screen.blit(faixa, (0, 0))

        # Título da Fase e Dificuldade
        txt_tit = fonte_m.render(f"Fase {self.config['numero']}: {self.config['titulo']}", True, COR_AMARELO)
        screen.blit(txt_tit, (20, 8))
        txt_dif = fonte_p.render(self.config['dificuldade_texto'], True, self.config['cor_dificuldade'])
        screen.blit(txt_dif, (20, 30))

        # Barra de Vida (HP)
        hp_x = 360
        hp_y = 14
        larg_hp = 160
        alt_hp = 18
        pygame.draw.rect(screen, (40, 40, 50), (hp_x, hp_y, larg_hp, alt_hp), border_radius=4)
        pct_hp = max(0.0, self.jogador.vida / self.jogador.vida_max)
        cor_hp = COR_VERDE if pct_hp > 0.5 else (COR_AMARELO if pct_hp > 0.25 else COR_VERMELHO)
        pygame.draw.rect(screen, cor_hp, (hp_x, hp_y, int(larg_hp * pct_hp), alt_hp), border_radius=4)
        pygame.draw.rect(screen, (200, 200, 210), (hp_x, hp_y, larg_hp, alt_hp), 1, border_radius=4)
        txt_hp = fonte_p.render(f"❤️ {self.jogador.vida}/{self.jogador.vida_max}", True, COR_BRANCO)
        screen.blit(txt_hp, (hp_x + 35, hp_y + 1))

        # Barra Secundária Contextual (Oxigênio na Fase 5/8 ou Hidratação na Fase 2)
        num = self.config["numero"]
        if num == 2:
            pct_hid = self.jogador.hidratacao / self.jogador.hidratacao_max
            pygame.draw.rect(screen, (40, 40, 50), (hp_x, hp_y + 20, larg_hp, 12), border_radius=3)
            pygame.draw.rect(screen, (52, 152, 219), (hp_x, hp_y + 20, int(larg_hp * pct_hid), 12), border_radius=3)
            txt_hid = fonte_p.render("☀️ Hidratação", True, (200, 225, 255))
            screen.blit(txt_hid, (hp_x + larg_hp + 8, hp_y + 18))
        elif num in [5, 8]:
            pct_ox = self.jogador.oxigenio / self.jogador.oxigenio_max
            pygame.draw.rect(screen, (40, 40, 50), (hp_x, hp_y + 20, larg_hp, 12), border_radius=3)
            pygame.draw.rect(screen, (41, 128, 185), (hp_x, hp_y + 20, int(larg_hp * pct_ox), 12), border_radius=3)
            txt_ox = fonte_p.render("🤿 Fôlego/Máscara", True, (200, 225, 255))
            screen.blit(txt_ox, (hp_x + larg_hp + 8, hp_y + 18))

        # Cronômetro Regressivo
        mins = int(self.tempo_restante // 60)
        secs = int(self.tempo_restante % 60)
        cor_tempo = COR_VERMELHO if self.tempo_restante < 15 else COR_AMARELO
        txt_t = fonte_m.render(f"⏱️ {mins:02d}:{secs:02d}", True, cor_tempo)
        screen.blit(txt_t, (self.largura_tela - 270, 16))

        # Botão Abandonar / Menu de Fases
        pygame.draw.rect(screen, (52, 73, 94), (self.largura_tela - 130, 10, 115, 34), border_radius=6)
        txt_esc = fonte_p.render("[ESC] Menu", True, COR_BRANCO)
        screen.blit(txt_esc, (self.largura_tela - 110, 18))

        # Painel Lateral Direito de Objetivos
        larg_obj = 230
        painel_obj = pygame.Surface((larg_obj, 140), pygame.SRCALPHA)
        painel_obj.fill((20, 25, 35, 215))
        screen.blit(painel_obj, (self.largura_tela - larg_obj - 10, 64))
        pygame.draw.rect(screen, COR_AMARELO, (self.largura_tela - larg_obj - 10, 64, larg_obj, 140), 1, border_radius=6)

        txt_obj_tit = fonte_p.render("📋 OBJETIVOS DA MISSÃO:", True, COR_AMARELO)
        screen.blit(txt_obj_tit, (self.largura_tela - larg_obj, 72))

        oy = 94
        for anim in self.animais_fase:
            salvo = anim in self.animais_resgatados
            cor_a = COR_VERDE if salvo else (210, 215, 225)
            marca = "✓ " if salvo else "○ "
            txt_a = fonte_p.render(f"{marca} {anim.nome}", True, cor_a)
            screen.blit(txt_a, (self.largura_tela - larg_obj + 8, oy))
            oy += 20

        # Alerta de Evacuação se todos foram resgatados
        if len(self.animais_resgatados) == len(self.animais_fase):
            txt_ev = fonte_p.render("★ IR PARA ZONA DE RESGATE!", True, COR_OURO)
            screen.blit(txt_ev, (self.largura_tela - larg_obj + 8, oy + 4))

        # Inventário Rápido no Canto Inferior Esquerdo
        inv_y = self.altura_tela - 40
        itens_txt = []
        for it, qtd in self.jogador.inventario.items():
            if qtd > 0:
                itens_txt.append(f"{it.capitalize()}: {qtd}")
        if num == 8 and self.jogador.inventario.get("extintor", 0) > 0:
            itens_txt.append("[ESPAÇO] Usar Extintor")

        if itens_txt:
            fundo_inv = pygame.Surface((380, 32), pygame.SRCALPHA)
            fundo_inv.fill((20, 25, 35, 220))
            screen.blit(fundo_inv, (10, inv_y - 2))
            txt_inv = fonte_p.render("🎒 " + " | ".join(itens_txt), True, (240, 240, 240))
            screen.blit(txt_inv, (18, inv_y + 4))


# =============================================================================
# MODAL DE RESULTADO DA FASE (VITÓRIA OU DERROTA)
# =============================================================================
class ModalResultadoFase:
    """Exibido ao terminar uma fase com sucesso ou falha."""
    def __init__(self, largura_tela, altura_tela, vitoria, fase_config, estrelas=0, motivo="", tempo_gasto=0):
        self.largura_tela = largura_tela
        self.altura_tela = altura_tela
        self.vitoria = vitoria
        self.fase_config = fase_config
        self.estrelas = estrelas
        self.motivo = motivo
        self.tempo_gasto = int(tempo_gasto)

        self.w = 560
        self.h = 420
        self.x = (largura_tela - self.w) // 2
        self.y = (altura_tela - self.h) // 2
        self.rect = pygame.Rect(self.x, self.y, self.w, self.h)

        # Botões de Ação
        if vitoria:
            self.btn_proxima = Botao((self.x + 40, self.y + self.h - 60, 220, 42), "▶ Próxima Fase", COR_VERDE_ESCURO, COR_VERDE)
            self.btn_zoo = Botao((self.x + 300, self.y + self.h - 60, 220, 42), "🐾 Ir ao Zoológico", COR_AZUL_ESCURO, COR_AZUL)
        else:
            self.btn_tentar = Botao((self.x + 40, self.y + self.h - 60, 220, 42), "🔄 Tentar Novamente", COR_VERMELHO_ESCURO, COR_VERMELHO)
            self.btn_menu = Botao((self.x + 300, self.y + self.h - 60, 220, 42), "☰ Menu de Fases", (52, 73, 94), (70, 90, 115))

    def update(self, mouse_pos):
        if self.vitoria:
            self.btn_proxima.update(mouse_pos)
            self.btn_zoo.update(mouse_pos)
        else:
            self.btn_tentar.update(mouse_pos)
            self.btn_menu.update(mouse_pos)

    def draw(self, screen, fontes):
        fonte_p = fontes["pequena"]
        fonte_m = fontes["media"]
        fonte_g = fontes["grande"]

        # Escurece fundo
        overlay = pygame.Surface((self.largura_tela, self.altura_tela), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))

        # Painel Central
        painel = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
        painel.fill(COR_PAINEL)
        screen.blit(painel, self.rect.topleft)

        cor_borda = COR_AMARELO if self.vitoria else COR_VERMELHO
        pygame.draw.rect(screen, cor_borda, self.rect, width=3, border_radius=14)

        if self.vitoria:
            txt_tit = fonte_g.render("🏆 FASE CONCLUÍDA COM SUCESSO!", True, COR_OURO)
            screen.blit(txt_tit, txt_tit.get_rect(center=(self.x + self.w // 2, self.y + 35)))

            # Exibição de Estrelas
            estrelas_str = "★ " * self.estrelas + "☆ " * (3 - self.estrelas)
            txt_est = fonte_g.render(estrelas_str, True, COR_AMARELO)
            screen.blit(txt_est, txt_est.get_rect(center=(self.x + self.w // 2, self.y + 75)))

            txt_info = fonte_m.render(f"Fase {self.fase_config['numero']}: {self.fase_config['titulo']}", True, (220, 230, 240))
            screen.blit(txt_info, txt_info.get_rect(center=(self.x + self.w // 2, self.y + 115)))

            # Estatísticas da Conquista
            dy = self.y + 155
            linhas = [
                f"• Tempo total de expedição: {self.tempo_gasto} segundos",
                f"• Animais salvos e catalogados: {', '.join(self.fase_config['animais_alvos'])}",
                "• Todos os animais resgatados já podem ser acomodados no seu Zoológico!",
                f"• Próxima fase desbloqueada: Fase {min(8, self.fase_config['numero'] + 1)}"
            ]
            for linha in linhas:
                txt_l = fonte_p.render(linha, True, (210, 220, 230))
                screen.blit(txt_l, (self.x + 35, dy))
                dy += 26

            self.btn_proxima.draw(screen, fonte_m)
            self.btn_zoo.draw(screen, fonte_m)

        else:
            txt_tit = fonte_g.render("⚠️ EXPEDIÇÃO FALHOU!", True, COR_VERMELHO)
            screen.blit(txt_tit, txt_tit.get_rect(center=(self.x + self.w // 2, self.y + 35)))

            txt_info = fonte_m.render(f"Fase {self.fase_config['numero']}: {self.fase_config['titulo']}", True, (220, 230, 240))
            screen.blit(txt_info, txt_info.get_rect(center=(self.x + self.w // 2, self.y + 75)))

            # Motivo
            txt_mot = fonte_p.render(self.motivo, True, (255, 180, 180))
            screen.blit(txt_mot, txt_mot.get_rect(center=(self.x + self.w // 2, self.y + 120)))

            # Dica Estratégica do Zoólogo
            caixa_dica = pygame.Rect(self.x + 30, self.y + 160, self.w - 60, 120)
            pygame.draw.rect(screen, (35, 30, 40), caixa_dica, border_radius=8)
            pygame.draw.rect(screen, (120, 60, 60), caixa_dica, 1, border_radius=8)

            txt_tit_dica = fonte_m.render("💡 Dica do Zoólogo:", True, COR_AMARELO)
            screen.blit(txt_tit_dica, (caixa_dica.x + 16, caixa_dica.y + 12))

            # Quebra de texto da dica
            palavras = self.fase_config['dica'].split(' ')
            l_atual = ""
            dy = caixa_dica.y + 40
            for p in palavras:
                t = l_atual + p + " "
                if fonte_p.size(t)[0] < (caixa_dica.width - 32):
                    l_atual = t
                else:
                    screen.blit(fonte_p.render(l_atual, True, (230, 235, 245)), (caixa_dica.x + 16, dy))
                    dy += 22
                    l_atual = p + " "
            if l_atual:
                screen.blit(fonte_p.render(l_atual, True, (230, 235, 245)), (caixa_dica.x + 16, dy))

            self.btn_tentar.draw(screen, fonte_m)
            self.btn_menu.draw(screen, fonte_m)

    def tratar_clique(self, mouse_pos):
        if self.vitoria:
            if self.btn_proxima.rect.collidepoint(mouse_pos):
                return "proxima"
            if self.btn_zoo.rect.collidepoint(mouse_pos):
                return "zoologico"
        else:
            if self.btn_tentar.rect.collidepoint(mouse_pos):
                return "tentar_novamente"
            if self.btn_menu.rect.collidepoint(mouse_pos):
                return "menu_fases"
        return None


# =============================================================================
# MENU DE SELEÇÃO DAS 8 FASES (CARDS DE FASE)
# =============================================================================
class MenuSelecaoFases:
    """Tela de seleção interativa das 8 fases do jogo."""
    def __init__(self, largura_tela, altura_tela, gerenciador_fases):
        self.largura = largura_tela
        self.altura = altura_tela
        self.gerenciador = gerenciador_fases

        # Botões inferiores
        self.btn_voltar = Botao((30, altura_tela - 55, 200, 38), "← Voltar ao Menu", (52, 73, 94), (70, 90, 115))
        self.btn_zoo = Botao((largura_tela - 230, altura_tela - 55, 200, 38), "🐾 Ir ao Zoológico", COR_AZUL_ESCURO, COR_AZUL)

        # Retângulos dos 8 cards de fase (dispostos em 2 linhas de 4 colunas)
        self.cards = []
        larg_card = 224
        alt_card = 250
        espaco_x = 18
        espaco_y = 20
        offset_x = (largura_tela - (larg_card * 4 + espaco_x * 3)) // 2
        offset_y = 110

        for i in range(8):
            col = i % 4
            lin = i // 4
            cx = offset_x + col * (larg_card + espaco_x)
            cy = offset_y + lin * (alt_card + espaco_y)
            self.cards.append(pygame.Rect(cx, cy, larg_card, alt_card))

    def update(self, mouse_pos):
        self.btn_voltar.update(mouse_pos)
        self.btn_zoo.update(mouse_pos)

    def draw(self, screen, fontes):
        fonte_p = fontes["pequena"]
        fonte_m = fontes["media"]
        fonte_g = fontes["grande"]

        # Fundo do menu
        screen.fill((18, 22, 30))

        # Cabeçalho Principal
        txt_tit = fonte_g.render("CAMPANHA DO GUARDIÃO — 8 FASES ECOLÓGICAS", True, COR_AMARELO)
        screen.blit(txt_tit, txt_tit.get_rect(center=(self.largura // 2, 36)))

        txt_sub = fonte_p.render("Cada fase apresenta aumento significativo de dificuldade, perigos ambientais e novas espécies.", True, (180, 195, 210))
        screen.blit(txt_sub, txt_sub.get_rect(center=(self.largura // 2, 70)))

        mouse_pos = pygame.mouse.get_pos()

        # Renderização dos 8 Cards de Fases
        for idx, dados in enumerate(DADOS_DAS_OITO_FASES):
            r = self.cards[idx]
            num_fase = idx + 1
            desbloqueada = num_fase in self.gerenciador.fases_desbloqueadas
            concluida = num_fase in self.gerenciador.fases_concluidas
            hover = r.collidepoint(mouse_pos)

            # Cor de fundo do card
            if not desbloqueada:
                cor_fundo = (28, 30, 36)
                cor_borda = (60, 65, 75)
            elif hover:
                cor_fundo = (38, 48, 64)
                cor_borda = COR_AMARELO
            else:
                cor_fundo = (28, 36, 48)
                cor_borda = dados["cor_dificuldade"]

            pygame.draw.rect(screen, cor_fundo, r, border_radius=10)
            pygame.draw.rect(screen, cor_borda, r, width=2, border_radius=10)

            # Número da Fase
            txt_num = fonte_m.render(f"FASE {num_fase}", True, dados["cor_dificuldade"] if desbloqueada else (120, 125, 135))
            screen.blit(txt_num, (r.x + 12, r.y + 12))

            # Título da Fase
            txt_nome = fonte_p.render(dados["titulo"], True, COR_BRANCO if desbloqueada else (140, 145, 155))
            screen.blit(txt_nome, (r.x + 12, r.y + 36))

            # Subtítulo / Tema
            txt_subt = fonte_p.render(f"[{dados['subtitulo']}]", True, (180, 190, 205) if desbloqueada else (100, 105, 115))
            screen.blit(txt_subt, (r.x + 12, r.y + 56))

            # Dificuldade (Estrelas)
            estrelas_dif = "★" * num_fase + "☆" * (8 - num_fase)
            txt_dif = fonte_p.render(f"Dif: {estrelas_dif}", True, dados["cor_dificuldade"] if desbloqueada else (90, 95, 105))
            screen.blit(txt_dif, (r.x + 12, r.y + 80))

            # Tempo e Animais Alvo
            txt_t = fonte_p.render(f"⏱️ Tempo: {dados['tempo_limite']}s", True, (210, 215, 220) if desbloqueada else (100, 105, 115))
            screen.blit(txt_t, (r.x + 12, r.y + 104))

            txt_alvos_tit = fonte_p.render("Alvos a Resgatar:", True, COR_AMARELO if desbloqueada else (110, 115, 125))
            screen.blit(txt_alvos_tit, (r.x + 12, r.y + 128))

            alvos_str = ", ".join(dados["animais_alvos"][:2])
            if len(dados["animais_alvos"]) > 2:
                alvos_str += "..."
            txt_alvos = fonte_p.render(alvos_str, True, (220, 230, 240) if desbloqueada else (110, 115, 125))
            screen.blit(txt_alvos, (r.x + 12, r.y + 148))

            # Status Inferior do Card
            if concluida:
                estrelas_obtidas = self.gerenciador.fases_concluidas[num_fase].get("estrelas", 1)
                est_str = "★" * estrelas_obtidas + "☆" * (3 - estrelas_obtidas)
                txt_status = fonte_m.render(f"CONCLUÍDA {est_str}", True, COR_OURO)
            elif desbloqueada:
                txt_status = fonte_m.render("▶ DISPONÍVEL", True, COR_VERDE)
            else:
                txt_status = fonte_m.render("🔒 BLOQUEADA", True, (130, 135, 145))

            screen.blit(txt_status, txt_status.get_rect(center=(r.centerx, r.bottom - 22)))

        # Botões Inferiores
        self.btn_voltar.draw(screen, fonte_m)
        self.btn_zoo.draw(screen, fonte_m)

    def tratar_clique(self, mouse_pos):
        if self.btn_voltar.rect.collidepoint(mouse_pos):
            return "voltar", None
        if self.btn_zoo.rect.collidepoint(mouse_pos):
            return "zoologico", None

        # Checa clique em um card de fase
        for idx, r in enumerate(self.cards):
            num_fase = idx + 1
            if r.collidepoint(mouse_pos):
                if num_fase in self.gerenciador.fases_desbloqueadas:
                    return "iniciar_fase", num_fase
                else:
                    return "bloqueada", num_fase

        return None, None


# =============================================================================
# GERENCIADOR GERAL DAS 8 FASES (INTEGRAÇÃO COM O JOGO)
# =============================================================================
class GerenciadorFases:
    """
    Gerencia a campanha completa de 8 fases do jogo:
    progresso, desbloqueio sequencial, histórico de estrelas e execução.
    """
    def __init__(self, lista_animais, colecao, zoologico, audio):
        self.lista_animais = lista_animais
        self.colecao = colecao
        self.zoologico = zoologico
        self.audio = audio

        self.fases_desbloqueadas = [1]
        self.fases_concluidas = {}  # {num_fase: {"estrelas": int, "tempo": int}}
        self.fase_ativa = None
        self.cena_fase_atual = None
        self.modal_resultado = None

    def obter_config_fase(self, numero_fase):
        for f in DADOS_DAS_OITO_FASES:
            if f["numero"] == numero_fase:
                return f
        return DADOS_DAS_OITO_FASES[0]

    def iniciar_fase(self, numero_fase, jogador, largura_tela, altura_tela):
        """Inicia uma fase específica."""
        config = self.obter_config_fase(numero_fase)
        self.fase_ativa = config
        self.cena_fase_atual = CenaFase(largura_tela, altura_tela, config, self.lista_animais, jogador, self.audio)
        self.modal_resultado = None

    def concluir_fase(self, tempo_gasto):
        """Registra a conclusão da fase e desbloqueia a próxima."""
        if not self.cena_fase_atual:
            return

        num = self.fase_ativa["numero"]
        estrelas = self.cena_fase_atual.estrelas_obtidas
        self.fases_concluidas[num] = {
            "estrelas": max(estrelas, self.fases_concluidas.get(num, {}).get("estrelas", 1)),
            "tempo": tempo_gasto
        }

        # Desbloqueia a próxima fase
        prox = num + 1
        if prox <= 8 and prox not in self.fases_desbloqueadas:
            self.fases_desbloqueadas.append(prox)

    def reiniciar_fase_atual(self, jogador, largura_tela, altura_tela):
        if self.fase_ativa:
            self.iniciar_fase(self.fase_ativa["numero"], jogador, largura_tela, altura_tela)
